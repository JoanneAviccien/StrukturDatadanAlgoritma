#ifndef menu_h
#define menu_h

#include "singlylink.h"

void addbook(linkedlist **lemaribuku);

#endif // !menu_h
